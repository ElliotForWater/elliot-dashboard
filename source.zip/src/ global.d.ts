declare module '*.module.css'

declare module 'react-odometerjs'
declare module '*.svg?inline' {
  const content: any
  export default content
}

declare module '*.jpg'
declare module '*.png'
declare module '*.svg'
